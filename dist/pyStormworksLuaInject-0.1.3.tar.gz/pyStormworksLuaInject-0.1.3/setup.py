from setuptools import setup, find_packages

# This call to setup() does all the work
setup(
    name="pyStormworksLuaInject",
    version="0.1.3",
    packages=find_packages()
)